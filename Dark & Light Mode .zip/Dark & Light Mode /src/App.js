import logo from './logo.svg';
import './App1.css';
import Navbar from './components/Navbar';
//import Textform from './components/Textform';
import About from './components/About';

function App() {
  return (
    /*<>
    <h1>Learning Phase</h1>
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a 
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learning React JS from Harry
        </a>
      </header>
    </div>
    </>*/

    /*<div className='blank'>Lovely</div>*/
    <>
      < Navbar title="TextUtils" textAbout="About Us" / >
      <div className="container my-3">
          {/* <Textform heading="Enter the Text to analyse"/> */}
          <About/>
      </div> 
    </>
  );
}

export default App;
